import tkinter as tk
from tkinter import messagebox
from tkinter import scrolledtext
import turtle
import os
import csv
from datetime import datetime

# --- Teacher Passwords (Class Teachers Only) ---
TEACHER_ACCOUNTS = {
    "p1pass": "P.1",
    "p2pass": "P.2",
    "p3pass": "P.3",
    "p4pass": "P.4",
    "p5pass": "P.5",
    "p6pass": "P.6",
    "p7pass": "P.7"
}

# --- SECRET HEADTEACHER PASSWORD ---
HEADTEACHER_PASSWORD = "headteacher777"

# --- AUTOMATIC DUMMY DATA INJECTION FOR YOUR PRESENTATION ---
def inject_dummy_data():
    # Only create dummy data if the log file does not exist yet or is empty
    if not os.path.exists("student_welfare_log.txt") or os.path.getsize("student_welfare_log.txt") == 0:
        dummy_records = [
            "07:30 AM         | Okello John        | P.1    | ALERT | BFK:No  | MAT:Yes | JNY:Walk | HLTH:Strong | ASG:Yes | Issues: Checked.\n",
            "07:35 AM         | Babirye Sarah      | P.2    | NORMAL| BFK:Yes | MAT:Yes | JNY:Boda | HLTH:Strong | ASG:Yes | Issues: Checked.\n",
            "07:42 AM         | Musoke David       | P.3    | ALERT | BFK:Yes | MAT:No  | JNY:Walk | HLTH:Sick   | ASG:No  | Issues: Checked.\n",
            "07:48 AM         | Kamau Peter        | P.4    | NORMAL| BFK:Yes | MAT:Yes | JNY:Bus  | HLTH:Strong | ASG:Yes | Issues: Checked.\n",
            "07:55 AM         | Mukasa Emmanuel    | P.5    | ALERT | BFK:No  | MAT:No  | JNY:Walk | HLTH:Strong | ASG:No  | Issues: Checked.\n",
            "08:01 AM         | Namubiru Jane      | P.6    | NORMAL| BFK:Yes | MAT:Yes | JNY:Bicycle| HLTH:Strong | ASG:Yes | Issues: Checked.\n",
            "08:05 AM         | Ochen Denis        | P.7    | ALERT | BFK:Yes | MAT:Yes | JNY:Walk | HLTH:Sick   | ASG:Yes | Issues: Checked.\n",
            "08:10 AM         | Akello Mercy       | P.3    | NORMAL| BFK:Yes | MAT:Yes | JNY:Boda | HLTH:Strong | ASG:Yes | Issues: Checked.\n",
            "08:12 AM         | Nsubuga Peter      | P.1    | NORMAL| BFK:Yes | MAT:Yes | JNY:Bus  | HLTH:Strong | ASG:Yes | Issues: Checked.\n",
            "08:18 AM         | Atwine Blessings   | P.7    | ALERT | BFK:No  | MAT:Yes | JNY:Walk | HLTH:Strong | ASG:No  | Issues: Checked.\n"
        ]
        try:
            with open("student_welfare_log.txt", "w", encoding="utf-8") as file:
                file.writelines(dummy_records)
        except Exception as e:
            print(f"Error injecting dummy data: {e}")

# Call the function to create the fake records immediately
inject_dummy_data()


# --- Global Turtle Setup ---
screen = None
t = None
turtle_win = None  

def init_turtle():
    global screen, t, turtle_win
    if screen is None:
        screen = turtle.Screen()
        screen.setup(750, 550)
        screen.bgcolor("#EBF5FB")
        turtle_win = screen.getcanvas().winfo_toplevel()
        turtle_win.withdraw() 
        t = turtle.Turtle()
        t.speed(0)
        t.hideturtle()

def generate_report():
    now = datetime.now()
    reg_time = now.strftime("%I:%M %p")  
    reg_date = now.strftime("%B %d, %Y") 

    name = entry_name.get().strip()
    student_class = var_class.get()
    
    assignment = var_assignment.get()
    transport = var_transport.get()
    breakfast = var_breakfast.get()
    lunch = var_lunch.get()
    supplies = var_supplies.get()
    health = var_health.get()
    light = var_light.get()
    fav_subject = var_subject.get()
    
    if not name:
        messagebox.showwarning("Missing Info", "Please fill in your Name before submitting!")
        return

    alerts = []
    has_alert = False
    
    if assignment == "No":
        alerts.append("📝 ASSIGNMENT: Homework is incomplete today.")
        has_alert = True
    if lunch == "No":
        alerts.append("⚠️ NUTRITION: No lunch today. Hungry by 2:00 PM.")
        has_alert = True
    if transport == "Walk":
        alerts.append("🚶 DISTANCE: Student walks to school. Watch for fatigue.")
    if supplies == "No":
        alerts.append("✏️ SUPPLIES: Lacks enough pens or exercise books.")
        has_alert = True
    if health == "Sick":
        alerts.append("🩺 HEALTH: Feels unwell today. Monitor closely.")
        has_alert = True
    if light == "No":
        alerts.append("💡 HOME STUDY: No reading lamp at home.")

    status_str = "ALERT" if has_alert else "NORMAL"
    log_line = f"{reg_time:<16} | {name:<18} | {student_class:<6} | {status_str:<5} | " \
               f"BFK:{breakfast:<3} | MAT:{supplies:<3} | JNY:{transport:<4} | " \
               f"HLTH:{health:<4} | ASG:{assignment:<3} | Issues: Checked.\n"
    try:
        with open("student_welfare_log.txt", "a", encoding="utf-8") as file:
            file.write(log_line)
    except Exception as e:
        print(f"Log Error: {e}")

    root.withdraw()
    display_teacher_dashboard(name, student_class, assignment, transport, reg_time, reg_date, breakfast, alerts, has_alert, fav_subject)

def return_to_form(x, y):
    global t, turtle_win
    t.reset()  
    t.hideturtle()
    t.speed(0)
    turtle_win.withdraw()  
    
    entry_name.delete(0, tk.END)
    var_class.set("P.1")

    var_assignment.set("Yes")
    var_transport.set("Walk")
    var_breakfast.set("Yes")
    var_lunch.set("Yes")
    var_supplies.set("Yes")
    var_health.set("Strong")
    var_light.set("Yes")
    var_subject.set("Mathematics")
    
    canvas.yview_moveto(0)  
    root.deiconify()        

def display_teacher_dashboard(name, s_class, assignment, transport, reg_time, reg_date, breakfast, alerts, has_alert, fav_subject):
    global t, screen, turtle_win
    
    turtle_win.deiconify()
    screen.title(f"Welfare Summary: {name} ({s_class})")
    
    t.penup()
    t.goto(-350, 240)
    t.pendown()
    t.fillcolor("white")
    t.begin_fill()
    for _ in range(2):
        t.forward(700)
        t.right(90)
        t.forward(80)
    t.end_fill()
    
    t.penup()
    t.goto(-310, 180)
    t.pendown()
    status_color = "#E74C3C" if has_alert else "#2ECC71"
    t.fillcolor(status_color)
    t.begin_fill()
    t.circle(25)
    t.end_fill()
    
    t.penup()
    t.goto(-260, 205)
    t.pencolor("#2C3E50")
    t.write(f"STUDENT: {name.upper()}  |  CLASS: {s_class}", font=("Arial", 16, "bold"))
    
    t.goto(-260, 185)
    t.pencolor("#7F8C8D")
    t.write(f"Registered on: {reg_date} at {reg_time}", font=("Arial", 10, "bold"))
    
    t.goto(-260, 165)
    status_text = "🚨 ATTENTION REQUIRED" if has_alert else "🎉 READY TO LEARN!"
    t.pencolor(status_color)
    t.write(f"STATUS: {status_text}", font=("Arial", 11, "bold"))
    
    t.penup()
    t.goto(-350, 120)
    t.pendown()
    t.fillcolor("#FFFFFF")
    t.begin_fill()
    for _ in range(2):
        t.forward(280)
        t.right(90)
        t.forward(320)
    t.end_fill()
    
    t.penup()
    t.goto(-50, 120) 
    t.pendown()
    alert_box_color = "#FDEDEC" if has_alert else "#EAFAF1"
    t.fillcolor(alert_box_color)
    t.begin_fill()
    for _ in range(2):
        t.forward(400)
        t.right(90)
        t.forward(320)
    t.end_fill()
    t.penup()
    
    t.pencolor("#34495E")
    t.goto(-330, 85)
    t.write("📋 BACKGROUND DATA", font=("Arial", 13, "bold"))
    
    bg_info = [
        
        f"• Completed Homework: {assignment}",
        f"• Commute Type: {transport}",
        f"• Had Breakfast: {breakfast}"
    ]
    
    y = 50
    for info in bg_info:
        t.goto(-330, y)
        t.write(info, font=("Arial", 11, "normal"))
        y -= 28
        
    t.pencolor("#9B59B6")
    t.goto(-330, y - 10)
    t.write("🌟 FAVORITE SUBJECT", font=("Arial", 13, "bold"))
    t.goto(-330, y - 35)
    t.pencolor("black")
    t.write(f"Student loves {fav_subject}!", font=("Arial", 12, "italic"))
    
    t.pencolor("#C0392B" if has_alert else "#27AE60")
    t.goto(-30, 85)
    t.write("🚨 ACTIONABLE ALERTS", font=("Arial", 13, "bold"))
    
    y_alert = 50
    t.pencolor("black")
    if not alerts:
        t.goto(-30, y_alert)
        t.write("✅ Perfect! No tracking issues found.", font=("Arial", 11, "normal"))
    else:
        for alert in alerts:
            t.goto(-30, y_alert)
            t.write(alert, font=("Arial", 10, "normal"))
            y_alert -= 35

    t.goto(-180, -220)
    t.pencolor("#7F8C8D")
    t.write("👉 CLICK ANYWHERE ON THIS WINDOW TO RETURN TO THE FORM 👈", font=("Arial", 10, "bold"))
    screen.onclick(return_to_form)

# --- Role-Based Teacher / Head Teacher Admin Panel ---
def open_admin_panel():
    password = entry_pass.get().strip()
    
    if password == HEADTEACHER_PASSWORD:
        assigned_class = "All Classes"
        is_headteacher = True
    elif password in TEACHER_ACCOUNTS:
        assigned_class = TEACHER_ACCOUNTS[password]
        is_headteacher = False
    else:
        messagebox.showerror("Access Denied", "Invalid Password. Please double check.")
        return

    admin_win = tk.Toplevel(root)
    admin_win.title(f"Welfare Admin Portal - Dashboard")
    admin_win.geometry("980x620")
    admin_win.configure(bg="#ECEFF1")

    filter_frame = tk.Frame(admin_win, bg="#CFD8DC", pady=10)
    filter_frame.pack(fill=tk.X)

    tk.Label(filter_frame, text="Active View Profile:", font=("Arial", 10, "bold"), bg="#CFD8DC").grid(row=0, column=0, padx=(15, 5))
    var_admin_class_filter = tk.StringVar(value=assigned_class)
    admin_classes = ["All Classes", "P.1", "P.2", "P.3", "P.4", "P.5", "P.6", "P.7"]
    dropdown_filter = tk.OptionMenu(filter_frame, var_admin_class_filter, *admin_classes)
    dropdown_filter.config(font=("Arial", 9), width=14)
    dropdown_filter.grid(row=0, column=1, padx=5)

    if not is_headteacher:
        dropdown_filter.config(state="disabled")
        protection_text = "🔒 Class Teacher View Locked"
    else:
        protection_text = "👑 Head Teacher Master Control Active"

    tk.Label(filter_frame, text=protection_text, font=("Arial", 9, "italic"), fg="#37474F", bg="#CFD8DC").grid(row=0, column=2, padx=10)

    lbl_summary = tk.Label(admin_win, text="Welfare Summary Metrics Loading...", font=("Arial", 11, "bold"), bg="#B0BEC5", fg="#263238", pady=6)
    lbl_summary.pack(fill=tk.X)

    header_txt = f"{'TIME OF ARRIVAL':<16} | {'PUPIL NAME':<18} | {'CLASS':<6} | {'STATE':<5} | {'BFK':<3} | {'MAT':<3} | {'JNY':<4} | {'HLTH':<4} | {'ASG':<3} | REASON METRICS\n"
    header_txt += "-" * 115 + "\n"
    lbl_header = tk.Label(admin_win, text=header_txt, font=("Courier", 9, "bold"), bg="#ECEFF1", justify=tk.LEFT, anchor="w")
    lbl_header.pack(fill=tk.X, padx=15, pady=(10,0))

    log_display = scrolledtext.ScrolledText(admin_win, width=120, height=22, font=("Courier", 9))
    log_display.pack(pady=(0, 10), padx=15)
    log_display.tag_config("alert_highlight", background="#FFCDD2", foreground="#B71C1C")

    current_alert_filter = tk.BooleanVar(value=False)

    def load_data():
        filter_alerts_only = current_alert_filter.get()
        selected_class = var_admin_class_filter.get()
        log_display.configure(state='normal')
        log_display.delete('1.0', tk.END)
        
        if not os.path.exists("student_welfare_log.txt") or os.path.getsize("student_welfare_log.txt") == 0:
            log_display.insert(tk.END, "Database empty or log repository clean.")
            lbl_summary.config(text="Total Records: 0  |  Active Welfare Risk Flags: 0")
            log_display.configure(state='disabled')
            return

        with open("student_welfare_log.txt", "r", encoding="utf-8") as file:
            lines = file.readlines()

        total_checks = 0
        alert_count = 0
        records_found = False

        for line in lines:
            parts = line.split("|")
            if len(parts) < 4:
                continue
            line_class = parts[2].strip()
            line_status = parts[3].strip()

            if selected_class != "All Classes" and line_class != selected_class:
                continue

            total_checks += 1
            is_alert = "ALERT" in line_status
            if is_alert:
                alert_count += 1

            if filter_alerts_only and not is_alert:
                continue

            if is_alert:
                log_display.insert(tk.END, line, "alert_highlight")
            else:
                log_display.insert(tk.END, line)
            records_found = True

        lbl_summary.config(text=f"Class Account [{selected_class}] -> Total Records: {total_checks}  |  Active Risk Flags: {alert_count}")
        if not records_found:
            log_display.insert(tk.END, f"No matching records found for {selected_class} in this view context.")
        log_display.configure(state='disabled')

    def set_alert_filter(val):
        current_alert_filter.set(val)
        load_data()

    def export_to_csv():
        selected_class = var_admin_class_filter.get()
        filter_alerts_only = current_alert_filter.get()
        if not os.path.exists("student_welfare_log.txt") or os.path.getsize("student_welfare_log.txt") == 0:
            messagebox.showwarning("Export Failed", "No records found to export.")
            return

        csv_filename = f"Welfare_Export_{selected_class.replace(' ', '_')}.csv"
        try:
            with open("student_welfare_log.txt", "r", encoding="utf-8") as infile, \
                 open(csv_filename, "w", newline="", encoding="utf-8") as outfile:
                writer = csv.writer(outfile)
                writer.writerow(["Time of Arrival", "Pupil Name", "Class", "Status", "Breakfast", "Materials", "Journey", "Health", "Assignment Check", "Flags Detailed"])
                for line in infile:
                    parts = line.split("|")
                    if len(parts) < 10:
                        continue
                    line_class = parts[2].strip()
                    line_status = parts[3].strip()

                    if selected_class != "All Classes" and line_class != selected_class:
                        continue
                    if filter_alerts_only and "ALERT" not in line_status:
                        continue

                    row_data = [p.strip() for p in parts[:4]]
                    row_data.append(parts[4].split(":")[1].strip())
                    row_data.append(parts[5].split(":")[1].strip())
                    row_data.append(parts[6].split(":")[1].strip())
                    row_data.append(parts[7].split(":")[1].strip())
                    row_data.append(parts[8].split(":")[1].strip())
                    row_data.append(parts[9].replace("Issues:", "").strip())
                    writer.writerow(row_data)
            messagebox.showinfo("Export Successful", f"Data exported cleanly:\n{csv_filename}")
        except Exception as e:
            messagebox.showerror("Export Error", f"Could not export data: {str(e)}")

    def archive_and_clear_log():
        if not os.path.exists("student_welfare_log.txt") or os.path.getsize("student_welfare_log.txt") == 0:
            messagebox.showinfo("Action Cancelled", "The data log is already completely empty.")
            return
        confirm = messagebox.askyesnocancel("Term Clear Settings", "Would you like to ARCHIVE this term's data file safely before wiping it?\n\n"
                                            "[Yes] - Save an archived backup copy and clear logs\n"
                                            "[No] - Erase all history completely without backup\n"
                                            "[Cancel] - Do nothing")
        if confirm is True:
            date_str = datetime.now().strftime("%Y_%m_%d")
            backup_filename = f"Welfare_Archive_{date_str}.txt"
            try:
                os.rename("student_welfare_log.txt", backup_filename)
                open("student_welfare_log.txt", "w").close()
                messagebox.showinfo("Term Archived", f"Success! Saved as:\n'{backup_filename}'")
                load_data()
            except Exception as e:
                messagebox.showerror("Backup Error", f"Could not create file: {str(e)}")
        elif confirm is False:
            if messagebox.askyesno("Confirm Permanent Erasure", "Warning: Clean all data completely?"):
                open("student_welfare_log.txt", "w").close()
                load_data()

    var_admin_class_filter.trace_add("write", lambda *args: load_data())
    btn_frame = tk.Frame(admin_win, bg="#ECEFF1")
    btn_frame.pack(pady=5)

    tk.Button(btn_frame, text="⚠️ View Alerts Only", font=("Arial", 9, "bold"), bg="#FFCDD2", fg="#B71C1C", command=lambda: set_alert_filter(True)).grid(row=0, column=0, padx=10)
    tk.Button(btn_frame, text="📋 View All Pupils", font=("Arial", 9, "bold"), bg="#C8E6C9", fg="#1B5E20", command=lambda: set_alert_filter(False)).grid(row=0, column=1, padx=10)
    tk.Button(btn_frame, text="📥 Export View (CSV)", font=("Arial", 9, "bold"), bg="#B3E5FC", fg="#0D47A1", command=export_to_csv).grid(row=0, column=2, padx=10)

    if is_headteacher:
        tk.Button(btn_frame, text="🗑️ Term Reset / Archive", font=("Arial", 9, "bold"), bg="#CFD8DC", fg="#37474F", command=archive_and_clear_log).grid(row=0, column=3, padx=10)
    
    load_data()

def scroll_to_admin_panel():
    canvas.yview_moveto(1.0)
    entry_pass.focus_set()

# --- Tkinter Form GUI Construction ---
root = tk.Tk()
root.title("Digital Welfare Check Form")
root.geometry("500x600")

init_turtle()

HEADER_BG = "#2C3E50"
BTN_COLOR = "#27AE60"
LABEL_COLOR = "#2C3E50"

header_frame = tk.Frame(root, bg=HEADER_BG, height=80)
header_frame.pack(fill="x", side="top")
header_frame.pack_propagate(False)

tk.Label(header_frame, text="Daily Welfare Check Form", font=("Arial", 16, "bold"), fg="white", bg=HEADER_BG).pack(pady=10)
tk.Label(header_frame, text="Good morning pupils, Your Welbeing Matters fill this form to prepare for your day!", font=("Arial", 10, "italic"), fg="#EAF2F8", bg=HEADER_BG).pack()

btn_gear = tk.Button(header_frame, text="⛮", font=("Arial", 18), bg=HEADER_BG, fg="white",
                     bd=0, activebackground=HEADER_BG, cursor="hand2", command=scroll_to_admin_panel)
btn_gear.place(x=460, y=10)

container = tk.Frame(root)
container.pack(fill="both", expand=True)

canvas = tk.Canvas(container, bg="#F2F4F4", highlightthickness=0)
canvas.pack(side="left", fill="both", expand=True)

scrollbar = tk.Scrollbar(container, orient="vertical", command=canvas.yview)
scrollbar.pack(side="right", fill="y")

canvas.configure(yscrollcommand=scrollbar.set)

form_frame = tk.Frame(canvas, bg="#F2F4F4")
canvas_frame = canvas.create_window((0, 0), window=form_frame, anchor="nw")

def configure_scroll_region(event):
    canvas.configure(scrollregion=canvas.bbox("all"))
    canvas.itemconfig(canvas_frame, width=event.width)

canvas.bind('<Configure>', configure_scroll_region)

def create_label(text):
    lbl = tk.Label(form_frame, text=text, font=("Arial", 10, "bold"), fg=LABEL_COLOR, bg="#F2F4F4")
    lbl.pack(anchor="w", padx=25, pady=(12, 2))
    return lbl

# --- Form Layout Fields ---
create_label("1. What is your name?")
entry_name = tk.Entry(form_frame, width=40, font=("Arial", 10), bg="white", relief="solid", bd=1)
entry_name.pack(anchor="w", padx=25)

create_label("2. Which class are you in?")
var_class = tk.StringVar(value="P.1")
opt_class = tk.OptionMenu(form_frame, var_class, "P.1", "P.2", "P.3", "P.4", "P.5", "P.6", "P.7")
opt_class.config(bg="white", activebackground="#E5E7E9")
opt_class.pack(anchor="w", padx=25)



create_label("3. Did you complete your homework?")
var_assignment = tk.StringVar(value="Yes")
opt_assignment = tk.OptionMenu(form_frame, var_assignment, "Yes", "No")
opt_assignment.config(bg="white", activebackground="#E5E7E9")
opt_assignment.pack(anchor="w", padx=25)

create_label("4. How do you get to school?")
var_transport = tk.StringVar(value="Walk")
opt_transport = tk.OptionMenu(form_frame, var_transport, "Walk", "Boda", "Bicycle", "Bus")
opt_transport.config(bg="white", activebackground="#E5E7E9")
opt_transport.pack(anchor="w", padx=25)

create_label("5. Did you have anything to eat before coming to school?")
var_breakfast = tk.StringVar(value="Yes")
opt_breakfast = tk.OptionMenu(form_frame, var_breakfast, "Yes", "No")
opt_breakfast.config(bg="white", activebackground="#E5E7E9")
opt_breakfast.pack(anchor="w", padx=25)

create_label("6. Are you having lunch at school today?")
var_lunch = tk.StringVar(value="Yes")
opt_lunch = tk.OptionMenu(form_frame, var_lunch, "Yes", "No")
opt_lunch.config(bg="white", activebackground="#E5E7E9")
opt_lunch.pack(anchor="w", padx=25)

create_label("7. Do you have enough pens and exercise books for today?")
var_supplies = tk.StringVar(value="Yes")
opt_supplies = tk.OptionMenu(form_frame, var_supplies, "Yes", "No")
opt_supplies.config(bg="white", activebackground="#E5E7E9")
opt_supplies.pack(anchor="w", padx=25)

create_label("8. Do you feel strong and healthy today, or are you feeling sick?")
var_health = tk.StringVar(value="Strong")
opt_health = tk.OptionMenu(form_frame, var_health, "Strong", "Sick")
opt_health.config(bg="white", activebackground="#E5E7E9")
opt_health.pack(anchor="w", padx=25)

create_label("9. Do you have a lamp or light to use for reading at home at night?")
var_light = tk.StringVar(value="Yes")
opt_light = tk.OptionMenu(form_frame, var_light, "Yes", "No")
opt_light.config(bg="white", activebackground="#E5E7E9")
opt_light.pack(anchor="w", padx=25)

create_label("10. What is your favorite subject?")
var_subject = tk.StringVar(value="Mathematics")
opt_subject = tk.OptionMenu(form_frame, var_subject, "Mathematics", "English", "Science", "Social Studies (SST)", "Religious Education (RE)")
opt_subject.config(bg="white", activebackground="#E5E7E9")
opt_subject.pack(anchor="w", padx=25)

btn_submit = tk.Button(form_frame, text="Submit Answers Successfully", command=generate_report, 
                       bg=BTN_COLOR, fg="white", font=("Arial", 11, "bold"), activebackground="#1E8449", relief="raised", bd=2)
btn_submit.pack(pady=20, padx=25, anchor="w")

# --- Control Panel Login Footer Box ---
admin_frame = tk.LabelFrame(form_frame, text=" Secure Portal Access (Teachers & Head Teacher) ", font=("Arial", 9, "bold"), bg="#F2F4F4", fg="#37474F")
admin_frame.pack(fill="x", padx=25, pady=20)

tk.Label(admin_frame, text="Enter Password:", font=("Arial", 9), bg="#F2F4F4").grid(row=0, column=0, padx=5, pady=5)
entry_pass = tk.Entry(admin_frame, show="*", font=("Arial", 9), width=15)
entry_pass.grid(row=0, column=1, padx=5, pady=5)

btn_admin = tk.Button(admin_frame, text="Open Portal", font=("Arial", 9, "bold"), bg="#455A64", fg="white", command=open_admin_panel)
btn_admin.grid(row=0, column=2, padx=10, pady=5)

root.mainloop()